#include <stdio.h>
#include <string.h>
#include <wiringPi.h>
#include "libs/Paquete.h"
#include "libs/Serial.h"
#include "libs/Ethernet.h"
#include "libs/Slip.h"

#define BYTE unsigned char
#define CMD_BROADCAST 0
#define CMD_MSG 1
#define CMD_ACK 3
#define MAX_TTL 9
#define ACK_TIMEOUT 2000

Serial serial;
Slip slip;

const long interval = 10000;

bool debugFlag=true;

BYTE MAC[6]={0x7c,0x67,0xa2,0xf1,0x34,0};
BYTE EMPTY_MAC[6]={0,0,0,0,0,0};

struct CeldaNet{
    BYTE mac[6];
    int ttl;
    int port;
    char nombre[10];

    CeldaNet(){
        ttl=0;
        port=0;
        for(int i=0;i<6;i++)
            mac[i]=EMPTY_MAC[i];
    }
};

bool isEmpty(BYTE mac[6]);
bool compareTo(BYTE mac1[6], BYTE mac2[6]);
int findMac(BYTE mac[6]);

void imprimirTabla(char* nombre);
void imprimirPaquete(Ethernet paqEth);
void sendACK(int inPort, unsigned short int pnum);
void getACK(int timeOut, int port, BYTE mac[6]);
int calcularChecksum(BYTE* data, int length);

CeldaNet tablaRuteo[15];

int main (int argc, char *argv[]) {
    if(argc <= 3){
        printf("Error al ejecutar el programa.\n");
        return 0;
    }
    int nPuertos = argc - 3;
    int puertos[nPuertos];
    for(int i = 0; i < nPuertos; i++) {
        puertos[i] = serial.openPort(argv[3 + i], B9600);
        if (puertos[i] == -1) {
            printf("Error al abrir el puerto %s\n", argv[3 + i]);
            return 1;
        }
    }
    char aux[3];
    int destino;
    strcpy(aux, argv[1]);
    MAC[5] = (int)(aux[0] - '0') * 10 + (int)(aux[1] - '0');
    int in = fileno(stdin);
    int pos;
    BYTE buffer[30]; // Buffer para leer destinatario y mensaje

    unsigned long previousMillis = 0;
    unsigned long presentMillis;

    while(true){
        Ethernet paqEth;
        paquete paq;
        // Envío broadcast tabla
        presentMillis = millis();
        if ((presentMillis - previousMillis) >= interval){
            previousMillis = presentMillis;
            paq.cmd = CMD_BROADCAST;
            paq.op = MAX_TTL;
            paq.l = strlen(argv[2]);
            for (int i=0; i<paq.l; i++)
                paq.data[i] = argv[2][i];
            paq.empaqueta();
            for (int n = 0; n < paq.size(); n++)
                paqEth.data[n] = paq.frame[n];
            for (int i = 0; i < 6; i++)
                paqEth.origen[i] = MAC[i];
            memcpy(paqEth.destino, "\xFF\xFF\xFF\xFF\xFF\xFF", 6);
            paqEth.largo = paq.size();
            paqEth.empaqueta();

            for(int i = 0; i < nPuertos; i++){
                slip.writeSlip(puertos[i], paqEth.frame, paqEth.size());
            }
            imprimirTabla(argv[2]);
            printf("Ingrese destinatario y mensaje (formato: numero: mensaje): ");
        }
        // Leer destinatario y mensaje
        fflush(stdout);
        int x = serial.readPort(in, buffer, 30, 500);
        if(x > 0){
            buffer[x] = '\0'; // Añadido: terminación nula al buffer para evitar problemas de cadena
            char* token = strtok((char*)buffer, ":");
            if(token != NULL){
                destino = atoi(token); // Convertir el token a un número entero
                token = strtok(NULL, ":");
                if(token != NULL){
                    char* mensaje = token;
                    // Búsqueda de destinatario
                    if(destino >= 0 && destino < 15 && !isEmpty(tablaRuteo[destino].mac)) {
                        pos = destino;
                        // Empaquetado
                        paq.l = strlen(mensaje);
                        paq.op = MAX_TTL;
                        paq.cmd = 1;
                        for(int k = 0; k < paq.l; k++)
                            paq.data[k] = mensaje[k];
                        paq.cksm=calcularChecksum(paq.data, paq.l);
                        paq.empaqueta();
                        for(int j = 0; j < 6; j++){
                            paqEth.origen[j] = MAC[j];
                            paqEth.destino[j] = tablaRuteo[pos].mac[j];
                        }
                        paqEth.largo = paq.size();
                        for(int i = 0; i < paqEth.largo; i++)
                            paqEth.data[i] = paq.frame[i];
                        paqEth.empaqueta();

                        // Enviado
                        printf("Enviando mensaje a MAC: ");
                        for(int i = 0; i < 6; i++) {
                            printf("%02X ", paqEth.destino[i]);
                        }
                        printf("\n");
                        slip.writeSlip(tablaRuteo[pos].port, paqEth.frame, paqEth.size());
                        getACK(ACK_TIMEOUT, tablaRuteo[pos].port, tablaRuteo[pos].mac);
                        printf("Mensaje enviado a %d\n", pos); // Depuración
                        //imprimirPaquete(paqEth);
                    } else {
                        printf("Destinatario no encontrado en la tabla de ruteo.\n");
                    }
                }
            }
        }
        printf("\n");

        // proceso automatico
        for(int i = 0; i < nPuertos; i++){
            do{
            x = slip.readSlip(puertos[i], paqEth.frame, 100);
            if(x > 0){
                //imprimirPaquete(paqEth);
                paqEth.desempaqueta();
                if(compareTo(paqEth.destino, MAC)){ // comparar con mac propia
                    paqEth.desempaqueta();
                    for (int n = 0; n < paqEth.largo; n++)
                        paq.frame[n] = paqEth.data[n];
                    paq.desempaqueta();
                    if((paq.cmd == CMD_MSG)&&(paq.cksm==calcularChecksum(paq.data, paq.l))){
                        // Manejo de mensajes con cmd == 1
                        int namePos = findMac(paqEth.origen);
                        paq.data[paq.l] = '\0'; // Asegurar terminación nula
                        printf("%s dice: %s\n", tablaRuteo[namePos].nombre,paq.data);
                    }
                } else {
                    // reenviar paquete.
                    paquete paq;
                    for(int j = 0; j < paqEth.largo; j++)
                        paq.frame[j] = paqEth.data[j];
                    paq.desempaqueta();
                    if(paq.op > 0){
                        paq.op--;
                        paq.empaqueta();
                        for(int j = 0; j < paq.size(); j++)
                            paqEth.data[j] = paq.frame[j];
                        paqEth.empaqueta();
                        if(paq.cmd == CMD_BROADCAST){
                            // construcción de tabla de ruteo si el origen no es el mismo nodo
                            if(compareTo(MAC, paqEth.origen) == false){
                                int pos = findMac(paqEth.origen);
                                if(pos == -1){ // no esta
                                    pos = findMac(EMPTY_MAC);
                                    if(pos >= 0){
                                        for(int j = 0; j < 6; j++)
                                            tablaRuteo[pos].mac[j] = paqEth.origen[j];
                                        tablaRuteo[pos].port = puertos[i];
                                        tablaRuteo[pos].ttl = MAX_TTL - paq.op;
                                        paq.data[paq.l] = '\0';
                                        strcpy(tablaRuteo[pos].nombre, (const char *)paq.data);
                                    }
                                } else { // si está
                                    if(tablaRuteo[pos].ttl > MAX_TTL - paq.op){
                                        //printf("Actualización puerto %d | %d", i, puertos[i]);
                                        for(int j = 0; j < 6; j++)
                                            tablaRuteo[pos].mac[j] = paqEth.origen[j];
                                        tablaRuteo[pos].port = puertos[i];
                                        tablaRuteo[pos].ttl = MAX_TTL - paq.op;
                                        paq.data[paq.l] = '\0';
                                        strcpy(tablaRuteo[pos].nombre, (const char *)paq.data);
                                    }
                                }
                            }
                            // reenvío de paquete
                            for(int j = 0; j < nPuertos; j++) {
                                if(i != j) {
                                    slip.writeSlip(puertos[j], paqEth.frame, paqEth.size());

                                }
                            }
                        } else if(paq.cmd==CMD_MSG) {
                            // Renvío de paquetes ajenos al nodo NO Broadcast
                            sendACK(i, paq.pnum);
                            int pos = findMac(paqEth.destino);
                            if (pos>=0){
                                slip.writeSlip(tablaRuteo[pos].port, paqEth.frame, paqEth.size());
                                getACK(ACK_TIMEOUT, tablaRuteo[pos].port, tablaRuteo[pos].mac);
                            } else if ((pos=-1)&&(debugFlag==true)){
                                printf("Error: destino no encontrado\n");
                            }
                        }
                    }
                }
            }
            }while(x>0);

        }
    }
    printf("Done!!\n");
    return 0;
}

int findMac(BYTE mac[6]){
    for(int i = 0; i < 15; i++)
        if(compareTo(mac, tablaRuteo[i].mac))
            return i;
    return -1;
}

bool isEmpty(BYTE mac[6]){
    for(int i = 0; i < 6; i++){
        if(mac[i] != 0){
            return false;
        }
    }
    return true;
}

bool compareTo(BYTE mac1[6], BYTE mac2[6]){
    for(int i = 0; i < 6; i++){
        if(mac1[i] != mac2[i])
            return false;
    }
    return true;
}

void imprimirTabla(char* nombre){
    printf("\033[H"); // Reposiciona en la esquina superior izquierda
    printf("\033[J"); // Limpia desde el cursor hacia abajo
    printf("Hola %s! \n", nombre);
    printf("Nombre\t\t TTL\t Puerto\t MAC\n");
    for(int k=0; k<15; k++){ // Cambiado de k<=15 a k<15
        if (compareTo(tablaRuteo[k].mac,EMPTY_MAC)==false){
            printf("%d) %s \t %d \t %d \t", k, tablaRuteo[k].nombre, tablaRuteo[k].ttl, tablaRuteo[k].port);
            for(int i=0; i<6; i++)
                printf("%02X ", tablaRuteo[k].mac[i]);
            printf("\n");
        }
    }
    printf("\n\n\n");
    fflush(stdout);
}

void imprimirPaquete(Ethernet paqEth){
    paqEth.desempaqueta();
    paquete paq;
                    for(int j = 0; j < paqEth.largo; j++)
                        paq.frame[j] = paqEth.data[j];
                    paq.desempaqueta();
    for(int i=0; i<6; i++)
                printf("%02X ", paqEth.origen[i]);
    printf(" | ");
     for(int i=0; i<6; i++)
                printf("%02X ", paqEth.destino[i]);
    printf(" | CMD:%d | TTL:%d | DATA:|%s|\n",paq.cmd, paq.op, paq.data);

}

void sendACK(int inPort, unsigned short int pnum){
    paquete paq;
    Ethernet paqEth;
    int pos;

    paq.cmd = CMD_ACK;
    paq.pnum = pnum;
    paq.op = 1;
    paq.empaqueta();
    
    for(int n=0; n<paq.size(); n++)
        paqEth.data[n] = paq.frame[n];
    for(int i=0; i<6; i++)
        paqEth.origen[i]=MAC[i];
    // Búsqueda del puerto
    for(int i = 0; i < 15; i++){
        if((inPort == tablaRuteo[i].port)&&(tablaRuteo[i].ttl==1)){
            pos=i;
            break;
        }
    }
    for(int i=0; i<6; i++)
        paqEth.destino[i]=tablaRuteo[pos].mac[i];
    paqEth.largo=paq.size();
    paqEth.empaqueta();
    slip.writeSlip(tablaRuteo[pos].port, paqEth.frame, paqEth.size());
}

void getACK(int timeOut, int port, BYTE mac[6]){
    Ethernet paqEth;
    int pos1;
    int pos2;
    int x = slip.readSlip(port, paqEth.frame, timeOut);
    // Si el ACK no llega...
    if(x==0){
        for(int i = 0; i < 15; i++){
            if((port == tablaRuteo[i].port)&&(tablaRuteo[i].ttl==1)){
                pos1=i;
                break;
            }
        }
        pos2 = findMac(mac);
        // Vaciado de la MAC en la tabla
        for(int j = 0; j < 6; j++){
            tablaRuteo[pos1].mac[j] = EMPTY_MAC[j];
            tablaRuteo[pos2].mac[j] = EMPTY_MAC[j];
        }
        tablaRuteo[pos1].ttl = 0;
        tablaRuteo[pos1].port = 0;
        tablaRuteo[pos2].ttl = 0;
        tablaRuteo[pos2].port = 0;
    }
}

int calcularChecksum(BYTE* data, int length) {
    int checksum = 0;
    for (int i = 0; i < length; i++) {
        checksum += data[i];
    }
    return ~checksum & 0xFF; // Complemento a uno y asegurar que sea de 1 byte
}

