#ifndef SLIP_H_
#define SLIP_H_

#include <stdio.h>
#include <stdlib.h>
#include "Serial.h"

#define BYTE unsigned char

class Slip {
private:
    static const BYTE END; // 192
    static const BYTE ESC; // 219
    static const BYTE DC;  // 220
    static const BYTE DD;  // 221
    Serial serial;

public:
    Slip();
    void writeSlip(int port, BYTE* frame, int n);
    int readSlip(int port, BYTE* frame, int timeOut);
 };

#endif /* SLIP_H_ */