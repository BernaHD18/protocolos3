#ifndef ETHERNET_H
#define ETHERNET_H

#include <stdio.h>
#include <stdlib.h>

#define BYTE unsigned char

class Ethernet {
//   6 B   |   6 B   |  2 B   |1500 B| 4 B
// Destino | Origen  | largo  | DATA | FCS
public:
    static const int L_HEADER = 18;
    static const int MAX_DATA = 25; // 25 por adaptarse al protocolo de empaquetado
    static const int SIZE_FRAME = L_HEADER+MAX_DATA;

    Ethernet();
    BYTE origen[6];
    BYTE destino[6];
    int largo;
    BYTE data[MAX_DATA];
    int fcs;
    BYTE frame[SIZE_FRAME];

    void empaqueta();
    bool desempaqueta();
    int size();
 };

#endif /* ETHERNET_H */