/******************************************************************/
/* Author:   Dr. Juan Gonzalez Gomez. January, 2009               */
/* Modificada por: Dr. Ramiro Donoso Floody. 2024                 */
/*----------------------------------------------------------------*/
/* Serial communications in Linux                                 */
/*----------------------------------------------------------------*/
/* GPL LICENSE                                                    */
/******************************************************************/

#ifndef SERIAL_H
#define SERIAL_H

#include <termios.h>

#define BYTE unsigned char

class Serial {
public:
    // Se modifica a "const char *" para evitar definir estaticamente el serialName
    int  openPort(const char *serial_name, speed_t baud);
    void writePort(int serial_fd, BYTE *data, int size);
    int  readPort(int serial_fd, BYTE *data, int size, int timeout_msec);
    void closePort(int fd);
};
#endif
